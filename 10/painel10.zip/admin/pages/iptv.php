<!-- Main content -->
 <section class="content-header">
      <h1>
        Iptv
        <small>Listas de canais iptv</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="home.php"><i class="fa fa-dashboard"></i> Inicio</a></li>
        <li class="active">iptv</li>
      </ol>
    </section>
 <section class="content">
 <div class="row">

         <div class="col-lg-12">
         <!--<div class="callout callout-info lead">
          <h4><i class="fa fa-info"></i> LISTAS IPTV</h4>
          <p>Em smartphone requer modo paisagem.</p>
        </div>-->
       <div class="alert alert-info danger alert-dismissible">
       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
       <h4><i class="icon fa fa-info"></i> #Dica!</h4>
                Em smartphones requer modo paisagem.
              </div>

<!--<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true"></button>
                <h4><i class="icon fa fa-ban"></i> ATENÇÃO!</h4>
                Somente (lista publica) esta disponivel!
              </div>-->


<iframe style="border: none;" src="http://tvonline.plus/canais-tv/" width="327px" height="850px"  frameborder="0" scrolling="yes" allowfullscreen="yes" ></iframe>

